package Base;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Actions extends BaseDriver {

    public void getUrl(String url) {
        driver.get(url);
    }

    public void clickElement(WebElement element) {
        waitForElement(element);
        element.click();
    }

    public void waitForElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void sendKeysInElement(WebElement element, String keys) {
        waitForElement(element);
        element.sendKeys(keys);
    }

    public String getTextFromElement(WebElement element) {
        waitForElement(element);
        return element.getText();
    }
}
