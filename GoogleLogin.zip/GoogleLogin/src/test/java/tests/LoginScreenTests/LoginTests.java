package tests.LoginScreenTests;

import Base.Actions;
import Base.BaseDriver;
import Pages.SignInPage;
import commonUtils.ConfigReader;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.*;

public class LoginTests extends Actions {

    BaseDriver base = new BaseDriver();
    ConfigReader configReader = new ConfigReader();


//Can create more tests on Login screen with Forget Email and Create Account


    @BeforeMethod
    public void setUp() {
        String url = configReader.getPropertyValue("url");
        base.chooseDriver();
        getUrl(url);
    }

    @DataProvider(name = "LoginSuccessful")
    public static Object[][] credentials() {
        return new Object[][]{{"test@gmail.com", "test@1987"}};

    }

    @DataProvider(name = "InvalidUserName")
    public static Object[][] invalidUser() {
        return new Object[][]{{"test", "test"}};

    }

    @Test(dataProvider = "LoginSuccessful", enabled = false)
    public void testSuccessfulLogin(String username, String password) {

        SignInPage signInPage = PageFactory.initElements(driver, SignInPage.class);
        signInPage.setEmailInput(username);
        signInPage.clickNextButton();
        signInPage.setPasswordInput(password);
        signInPage.clickNextButton();
        Boolean flag = signInPage.isMessageDisplayed();
        Assert.assertTrue(flag);
        Reporter.log("Message Displayed assertion successful", true);

    }

    @Test(dataProvider = "InvalidUserName", priority = 1)
    public void testInvalidUserNameLogin(String username, String password) {
        SignInPage signInPage = PageFactory.initElements(driver, SignInPage.class);
        signInPage.setEmailInput(username);
        signInPage.clickNextButton();
        Boolean flag = signInPage.isUserNameErrorMessageDisplayed("Couldn't find your Google Account");
        Assert.assertTrue(flag);
        Reporter.log("\n" + "Error Message is displayed", true);
    }

    @Test(dataProvider = "LoginSuccessful", priority = 2)
    public void testInvalidPasswordLogin(String username, String password) {
        SignInPage signInPage = PageFactory.initElements(driver, SignInPage.class);
        signInPage.setEmailInput(username);
        signInPage.clickNextButton();
        signInPage.setPasswordInput(password);
        signInPage.clickNextButton();
        Boolean flag = signInPage.isPasswordErrorMessageDisplayed("Wrong password");
        Assert.assertTrue(flag);
        Reporter.log("Error Message is displayed", true);
    }

    @AfterMethod
    public void closeBrowser() {
        if (driver != null) {
            driver.close();
        }
    }

}
