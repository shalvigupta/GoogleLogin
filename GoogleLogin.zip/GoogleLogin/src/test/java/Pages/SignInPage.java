package Pages;

import Base.Actions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

import java.security.cert.X509Certificate;

public class SignInPage extends Actions {

    Actions actions = new Actions();

    @FindBy(id = "identifierId")
    WebElement emailInput;

    @FindBy(xpath = "//span[contains(text(),'Next')]")
    WebElement nextButton;

    @FindBy(name = "password")
    WebElement passwordInput;

    @FindBy(xpath = "//h1[contains(text(),'Welcome')]")
    WebElement welcomeMessage;

    @FindBy(xpath = "//input[@id='identifierId']/../../../following-sibling::div/div[2]/div[1]")
    WebElement errorUserNameMessage;

    @FindBy(xpath = "//div[@id='password']/div[2]/div")
    WebElement errorPasswordMessage;


    public void setEmailInput(String inputVal) {
        actions.sendKeysInElement(emailInput, inputVal);
        Reporter.log("\n" + inputVal + " is set to the field ", true);
    }

    public void setPasswordInput(String inputVal) {
        actions.sendKeysInElement(passwordInput, inputVal);
        Reporter.log("\n" + inputVal + " is set to the field ", true);
    }

    public void clickNextButton() {
        actions.clickElement(nextButton);
        Reporter.log("\n Next has been clicked", true);

    }

    public boolean isMessageDisplayed() {
        actions.waitForElement(welcomeMessage);
        int size = driver.findElements(By.xpath("//h1[contains(text(),'Welcome')]")).size();
        if (size > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isUserNameErrorMessageDisplayed(String expectedText) {
        actions.waitForElement(errorUserNameMessage);
        String actualText = actions.getTextFromElement(errorUserNameMessage);
        if (actualText.contains(expectedText)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isPasswordErrorMessageDisplayed(String expectedText) {
        actions.waitForElement(errorPasswordMessage);
        String actualText = actions.getTextFromElement(errorPasswordMessage);
        if (actualText.contains(expectedText)) {
            return true;
        } else {
            return false;
        }
    }
}